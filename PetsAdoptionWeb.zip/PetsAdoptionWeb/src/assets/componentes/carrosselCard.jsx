import React from 'react';
import { Button, Card, Col, Row, Container } from 'react-bootstrap';
import PropTypes from 'prop-types';

/**
 * Componente para exibir uma lista de produtos como cartões.
 *
 * @param {Object[]} produtos - Lista de produtos a serem exibidos.
 * @param {string} produtos[].id - ID único do produto.
 * @param {string} produtos[].imagemUrl - URL da imagem do produto.
 * @param {string} produtos[].titulo - Título do produto.
 * @param {string} produtos[].descricao - Descrição do produto.
 */
const ComprasCard = ({ produtos = [], onComprar }) => {
  // Handle button click event
  const handleClick = (produto) => {
    if (onComprar) {
      onComprar(produto);
    }
    console.log(`Produto clicado: ${produto.titulo}`);
  };

  return (
    <Container>
      <Row className="p-2">
        {produtos.map((produto) => (
          <Col key={produto.id} md={4} lg={3} className="mb-4">
            <Card>
              <Card.Img variant="top" src={produto.imagemUrl} />
              <Card.Body>
                <Card.Title>{produto.titulo}</Card.Title>
                <Card.Text>{produto.descricao}</Card.Text>
                <Button variant="primary" onClick={() => handleClick(produto)}>
                  Comprar
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

// Define the shape of the produto object
ComprasCard.propTypes = {
  produtos: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired, // or PropTypes.number if IDs are numeric
      imagemUrl: PropTypes.string.isRequired,
      titulo: PropTypes.string.isRequired,
      descricao: PropTypes.string.isRequired,
    })
  ).isRequired,
  onComprar: PropTypes.func, // Optional handler function for button click
};

export default ComprasCard;

