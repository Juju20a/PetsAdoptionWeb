import React from 'react';
import { Table, Container } from 'react-bootstrap';

const PetsTable = () => {
  const pets = [
    { id: 1, nome: 'Rex', especie: 'Cachorro', idade: '2 anos', imagem: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fbr.freepik.com%2Ffotos%2Fcachorro&psig=AOvVaw358Tq9Xyk8OPgPZgQ0UNVS&ust=1724415994379000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCNDIzqrMiIgDFQAAAAAdAAAAABAE' },
    { id: 2, nome: 'Mia', especie: 'Gato', idade: '1 ano', imagem: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fbr.freepik.com%2Ffotos%2Fcara-gato&psig=AOvVaw2X7kHmqVPHlzi1g29Ul3BI&ust=1724415947737000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCODiy5XMiIgDFQAAAAAdAAAAABAE' },
    { id: 3, nome: 'Luna', especie: 'Coelho', idade: '6 meses', imagem: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fpetanjo.com%2Fblog%2Fcoelho-de-estimacao-descubra-tudo-sobre-o-pet%2F&psig=AOvVaw2g5QY7xla6mvH8QSPXVyHI&ust=1724416020081000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCNDT0LbMiIgDFQAAAAAdAAAAABAE' },
  ];

  return (
    <Container className="p-3">
      <h2>Pets Disponíveis para Adoção</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Nome</th>
            <th>Espécie</th>
            <th>Idade</th>
            <th>Imagem</th>
          </tr>
        </thead>
        <tbody>
          {pets.map(pet => (
            <tr key={pet.id}>
              <td>{pet.nome}</td>
              <td>{pet.especie}</td>
              <td>{pet.idade}</td>
               <td><img src={pet.imagem} alt={pet.nome} style={{ width: '100px', height: 'auto' }} /></td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};

export default PetsTable;
