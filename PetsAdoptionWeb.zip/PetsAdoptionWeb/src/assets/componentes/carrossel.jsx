import { Carousel, Container, Image } from 'react-bootstrap';
import PropTypes from 'prop-types';
import './Carrosel.css';

/**
 * Componente Carrosel para exibir uma apresentação de imagens com títulos e descrições.
 *
 * @param {Object[]} itens - Lista de itens a serem exibidos no carrossel.
 * @param {string} itens[].imagemUrl - URL da imagem a ser exibida.
 * @param {string} itens[].titulo - Título da imagem.
 * @param {string} itens[].descricao - Descrição da imagem.
 */
const Carrosel = ({ itens = [] }) => {
  return (
    <Container fluid="sm" className="p-2">
      <Carousel controls={false}>
        {itens.map((item, i) => (
          <Carousel.Item key={i}>
            <Image fluid src={item.imagemUrl} alt={item.titulo} />
            <Carousel.Caption>
              <h3>{item.titulo}</h3>
              <p>{item.descricao}</p>
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>
    </Container>
  );
};

Carrosel.propTypes = {
  itens: PropTypes.arrayOf(
    PropTypes.shape({
      imagemUrl: PropTypes.string.isRequired,
      titulo: PropTypes.string.isRequired,
      descricao: PropTypes.string.isRequired,
    })
  ),
};

export default Carrosel;
