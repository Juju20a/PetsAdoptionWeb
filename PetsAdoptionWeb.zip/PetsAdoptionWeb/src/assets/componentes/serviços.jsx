import React from 'react';
import { Card, Col, Row } from 'react-bootstrap';

const Servicos = () => {
  const servicos = [
    { id: 1, titulo: 'Serviço 1', descricao: 'Descrição do serviço 1' },
    { id: 2, titulo: 'Serviço 2', descricao: 'Descrição do serviço 2' },
    { id: 3, titulo: 'Serviço 3', descricao: 'Descrição do serviço 3' },
  ];

  return (
    <Container className="p-3">
      <Row>
        {servicos.map(servico => (
          <Col key={servico.id} md={4}>
            <Card>
              <Card.Body>
                <Card.Title>{servico.titulo}</Card.Title>
                <Card.Text>{servico.descricao}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Servicos;
