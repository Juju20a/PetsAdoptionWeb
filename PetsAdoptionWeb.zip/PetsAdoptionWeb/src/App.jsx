import { useState } from 'react';
import './App.css'; // Certifique-se de que esse arquivo está corretamente configurado

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <header>
        <h1>PetJS</h1>
      </header>
      <main>
        <div className="card">
          <button 
            onClick={() => setCount(count => count + 1)} 
            aria-label="Increment count"
            className="count-button"
          >
            Count is {count}
          </button>
          <p>
            Edit <code>src/App.jsx</code> and save to test HMR.
          </p>
        </div>
        <p className="read-the-docs">
          Click on the Vite and React logos to learn more.
        </p>
      </main>
    </>
  );
}

export default App;
